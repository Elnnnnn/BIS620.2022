#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/

# Steps to adding a feature:
# 1. Specify the feature.
#   - What does it do?
#   - What will be shown?
# 2. Specify the interface
#   - Where should it go?
#   - Does it enhance the user experience?
# 3. Implement the feature without the UI
# 4. Integrate the feature.

#' @title  Shiny App
#' @description The function is to run a shiny app for clinical trial inquiry
#' @export
#' @importFrom shiny shinyApp fluidPage titlePanel sidebarLayout sidebarPanel
#' textInput selectInput dateRangeInput actionButton sliderInput mainPanel
#' tabPanel tabsetPanel reactive renderPlot h3 hr isolate withProgress
#' setProgress plotOutput
#' @importFrom wordcloud wordcloud
#' @importFrom DT dataTableOutput renderDataTable datatable
#' @importFrom utils head
#' @importFrom dplyr collect select mutate filter
#' @importFrom ggplot2 ggplot geom_line xlab ylab theme_bw
shiny_app <- function() {
  data("studies")
  max_num_studies <- 1000

  # Define UI for application that draws a histogram
  shinyApp(
    ui = fluidPage(

      # Application title
      titlePanel("Clinical Trials Query"),

      # Sidebar with a slider input for number of bins
      sidebarLayout(
        sidebarPanel(
          textInput("brief_title_kw", "Brief title keywords"),
          selectInput("source_class",
                      label = h3("Sponsor Type"),
                      choices = list("All" = "no_filter",
                        "Federal" = "FED",
                        "Individual" = "INDIV",
                        "Industry" = "INDUSTRY",
                        "Network" = "NETWORK",
                        "NIH" = "NIH",
                        "Other" = "OTHER",
                        "Other Government" = "OTHER_GOV",
                        "Unknow" = "Unknown"
                      ),
                      selected = 1),
          dateRangeInput("start_date_range", "Start Date Range:",
                         start = Sys.Date() - 3000, end = Sys.Date()),
          dateRangeInput("completion_date_range", "Completion Date Range:",
                         start = Sys.Date() - 3000, end = Sys.Date()),
          actionButton("update", "Change"),

          hr(),
          sliderInput("freq",
                      "Minimum Frequency:",
                      min = 1,  max = 50, value = 15),
          sliderInput("max",
                      "Maximum Number of Words:",
                      min = 1,  max = 300,  value = 100)
        ),

        # Show a plot of the generated distribution
        mainPanel(
          tabsetPanel(
            type = "tabs",
            tabPanel("Phase", plotOutput("phase_plot")),
            tabPanel("Concurrent", plotOutput("concurrent_plot")),
            tabPanel("Conditions", plotOutput("conditions_plot")),
            tabPanel("Word Cloud", plotOutput("wordcloud_plot")),
            tabPanel("World Map", plotOutput("country_plot")),
            tabPanel("American Map", plotOutput("states_us_plot")),
            tabPanel("Top 10 Investigated Diseases",
                     plotOutput("mesh_pie_chart"))
          ),
          DT::dataTableOutput("trial_table")
        )
      )
    ),

    # Define server logic required to draw a histogram
    server = function(input, output) {

      get_studies <- reactive({
        if (input$brief_title_kw != "") {
          si <- input$brief_title_kw |>
            strsplit(",") |>
            unlist() |>
            trimws()
          ret <- query_kwds(studies, si, "brief_title", match_all = TRUE)
        } else {
          ret <- studies
        }
        if (input$source_class != "no_filter") {
          ret <- ret |>
            filter(source_class %in% !!input$source_class)
        }else {
          ret <- ret
        }

        if (!is.null(input$start_date_range)) {
          start_date_s <- as.Date(input$start_date_range[1])
          end_date_s <- as.Date(input$start_date_range[2])
          ret <- ret |>
            filter(start_date >= start_date_s & start_date <= end_date_s)
        }

        if (!is.null(input$completion_date_range)) {
          start_date_c <- as.Date(input$completion_date_range[1])
          end_date_c <- as.Date(input$completion_date_range[2])
          ret <- ret |>
            filter(completion_date >= start_date_c &
                     completion_date <= end_date_c)
        }
        ret |>
          head(max_num_studies) |>
          collect()
      })

      output$phase_plot <- renderPlot({
        get_studies() |>
          plot_phase_histogram()
      })

      output$concurrent_plot <- renderPlot({
        c <- get_studies() |>
          select(start_date, completion_date) |>
          get_concurrent_trials()
        c$date <- as.Date(c$date, format = "%Y-%m-%d")
        c |> ggplot(aes(x = date, y = count)) +
          geom_line() +
          xlab("Date") +
          ylab("Count") +
          theme_bw()
      })

      output$conditions_plot <- renderPlot({
        get_studies() |>
          plot_conditions_histogram()
      })

      output$trial_table <-  DT::renderDataTable({
        df <- get_studies() |>
          table_with_link()
        DT::datatable(df[drop = FALSE], escape = FALSE)
      })

      terms <- reactive({
        # Change when the "update" button is pressed...
        input$update
        # ...but not for anything else
        isolate({
          withProgress({
            setProgress(message = "Processing corpus...")
            get_term_matrix(get_studies())
          })
        })
      })


      output$wordcloud_plot <- renderPlot({
        v <- terms()
        wordcloud(names(v), v, scale = c(4, 0.5),
                  min.freq = input$freq, max.words = input$max,
                  colors = brewer.pal(8, "Dark2"))
      })

      output$country_plot <- renderPlot({
        get_studies() |>
          plot_countries()
      })

      output$states_us_plot <- renderPlot({
        get_studies() |>
          plot_states_us()
      })

      output$mesh_pie_chart <- renderPlot({
        get_studies() |>
          pie_chart_mesh()
      })
    }
  )
}
